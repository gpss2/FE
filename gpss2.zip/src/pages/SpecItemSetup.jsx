import React from 'react';

const SpecItemSetup = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">규격품목 셋업</h1>
      <p>규격품목 셋업 페이지입니다.</p>
    </div>
  );
};

export default SpecItemSetup;
