import React from 'react';

const CuttingStart = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">계획 시작 및 잔재 생성</h1>
      <p>계획을 시작하고 잔재를 생성하는 페이지입니다.</p>
    </div>
  );
};

export default CuttingStart;
