import React from 'react';

const MaterialRegistration = () => {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">자재입고 등록</h1>
      <p>자재입고 등록 페이지입니다.</p>
    </div>
  );
};

export default MaterialRegistration;
