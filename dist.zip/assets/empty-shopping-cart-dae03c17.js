import"./index-49fdfb35.js";const p="/assets/empty-shopping-cart-95276f54.svg";export{p as s};
