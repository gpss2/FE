import{j as t,O as s}from"./index-49fdfb35.js";const e=()=>t.jsx(t.Fragment,{children:t.jsx(s,{})});export{e as default};
