const s="/assets/gold-afe5fc99.png";export{s};
