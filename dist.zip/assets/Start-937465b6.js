import{R as bt,V as gt,j as t,r as h,h as _,bQ as yt}from"./index-49fdfb35.js";import{S as wt}from"./SearchableSelect-5a3d41a2.js";import{P as xt}from"./PageContainer-2c0db8c9.js";import{P as je}from"./ParentCard-051201a9.js";import{S as ve}from"./StartDataGrid-e9c2064a.js";import{G as ie}from"./Grid-82011580.js";import{B as de}from"./Box-6a0909bf.js";import{S as ce}from"./Stack-5293f9ad.js";import{B as G}from"./Button-45ab0f5f.js";import{C as ue}from"./CircularProgress-b3bc82be.js";import{D as He,a as qe}from"./DialogContent-99006077.js";import{D as Qe}from"./DialogTitle-f4cced48.js";import{S as Ct}from"./Select-a3b07079.js";import{M as Ge}from"./MenuItem-6a8e00cf.js";import{T as ae}from"./TextField-f684a94c.js";import"./ListSubheader-7e48950a.js";import"./TableRow-043d8099.js";import"./Card-7a0bbc11.js";import"./CardHeader-516fbad0.js";import"./Divider-7472528d.js";import"./dividerClasses-23782532.js";import"./CardContent-9f8e4003.js";import"./createStack-ce6d82c8.js";import"./styled-177c0648.js";import"./useThemeProps-bbbbdfa7.js";import"./Modal-bf5f0063.js";import"./ownerDocument-613eb639.js";import"./ownerWindow-698471fc.js";import"./createChainedFunction-0bab83cf.js";import"./Fade-85175793.js";import"./utils-4a09ac9c.js";import"./Portal-70329398.js";import"./useId-6eaa6a63.js";import"./Popover-944d3be2.js";import"./Grow-f1bb1587.js";import"./List-4dbaad1a.js";import"./utils-5ebfb48b.js";import"./useControlled-ee441551.js";import"./formControlState-a1fb9590.js";import"./useFormControl-f3afd259.js";import"./listItemTextClasses-bb0006f6.js";import"./FormControl-1e69f00f.js";import"./isMuiElement-abbf0e9e.js";function St(f,d){for(var m=0;m<d.length;m++){var u=d[m];u.enumerable=u.enumerable||!1,u.configurable=!0,"value"in u&&(u.writable=!0),Object.defineProperty(f,u.key,u)}}function ke(f,d){return ke=Object.setPrototypeOf||function(m,u){return m.__proto__=u,m},ke(f,d)}function $e(f){return $e=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(d){return typeof d}:function(d){return d&&typeof Symbol=="function"&&d.constructor===Symbol&&d!==Symbol.prototype?"symbol":typeof d},$e(f)}function jt(f,d){if(d&&($e(d)==="object"||typeof d=="function"))return d;if(d!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return function(m){if(m===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return m}(f)}function pe(f){return pe=Object.setPrototypeOf?Object.getPrototypeOf:function(d){return d.__proto__||Object.getPrototypeOf(d)},pe(f)}var Ke,Ve,Xe,Ye,I={exports:{}};function vt(f){var d=function(){if(typeof Reflect>"u"||!Reflect.construct||Reflect.construct.sham)return!1;if(typeof Proxy=="function")return!0;try{return Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){})),!0}catch{return!1}}();return function(){var m,u=pe(f);if(d){var v=pe(this).constructor;m=Reflect.construct(u,arguments,v)}else m=u.apply(this,arguments);return jt(this,m)}}I.exports=function(){if(Ye)return Xe;Ye=1;var f=Ve?Ke:(Ve=1,Ke="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");function d(){}function m(){}return m.resetWarningCache=d,Xe=function(){function u(a,w,S,N,J,x){if(x!==f){var P=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw P.name="Invariant Violation",P}}function v(){return u}u.isRequired=u;var g={array:u,bool:u,func:u,number:u,object:u,string:u,symbol:u,any:u,arrayOf:v,element:u,elementType:u,instanceOf:v,node:u,objectOf:v,oneOf:v,oneOfType:v,shape:v,exact:v,checkPropTypes:m,resetWarningCache:d};return g.PropTypes=g,g}}()();var Ne,Le,Re,Ee=function(f){(function(g,a){if(typeof a!="function"&&a!==null)throw new TypeError("Super expression must either be null or a function");g.prototype=Object.create(a&&a.prototype,{constructor:{value:g,writable:!0,configurable:!0}}),a&&ke(g,a)})(v,bt.PureComponent);var d,m,u=vt(v);function v(g){var a;return function(w,S){if(!(w instanceof S))throw new TypeError("Cannot call a class as a function")}(this,v),(a=u.call(this,g)).container=null,a.window=null,a.windowCheckerInterval=null,a.released=!1,a.state={mounted:!1},a}return d=v,(m=[{key:"render",value:function(){return this.state.mounted?gt.createPortal(this.props.children,this.container):null}},{key:"componentDidMount",value:function(){this.window||this.container||(this.openChild(),this.setState({mounted:!0}))}},{key:"openChild",value:function(){var g,a=this,w=this.props,S=w.url,N=w.title,J=w.name,x=w.features,P=w.onBlock,T=w.onOpen,U=w.center;if(typeof U!="string"||x.width!==void 0&&x.height!==void 0){if(U==="parent")x.left=window.top.outerWidth/2+window.top.screenX-x.width/2,x.top=window.top.outerHeight/2+window.top.screenY-x.height/2;else if(U==="screen"){var b=window.screenLeft!==void 0?window.screenLeft:window.screen.left,E=window.screenTop!==void 0?window.screenTop:window.screen.top,R=window.innerWidth?window.innerWidth:document.documentElement.clientWidth?document.documentElement.clientWidth:window.screen.width,z=window.innerHeight?window.innerHeight:document.documentElement.clientHeight?document.documentElement.clientHeight:window.screen.height;x.left=R/2-x.width/2+b,x.top=z/2-x.height/2+E}}else console.warn("width and height window features must be present when a center prop is provided");if(this.window=window.open(S,J,(g=x,Object.keys(g).reduce(function(H,B){var O=g[B];return typeof O=="boolean"?H.push("".concat(B,"=").concat(O?"yes":"no")):H.push("".concat(B,"=").concat(O)),H},[]).join(","))),this.container=this.window.document.createElement("div"),this.windowCheckerInterval=setInterval(function(){a.window&&!a.window.closed||a.release()},50),this.window){if(this.window.document.title=N,this.container=this.window.document.getElementById("new-window-container"),this.container===null)this.container=this.window.document.createElement("div"),this.container.setAttribute("id","new-window-container"),this.window.document.body.appendChild(this.container);else{var c=this.window.document.getElementById("new-window-container-static");this.window.document.body.removeChild(c)}this.props.copyStyles&&setTimeout(function(){return H=document,B=a.window.document,O=B.createDocumentFragment(),Array.from(H.styleSheets).forEach(function(A){var Z;try{Z=A.cssRules}catch(q){console.error(q)}if(Z){var K=[];Array.from(A.cssRules).forEach(function(q){var W=q.type;if(W!==CSSRule.UNKNOWN_RULE){var te="";te=W===CSSRule.KEYFRAMES_RULE?function(L){var Q=["@keyframes",L.name,"{"];return Array.from(L.cssRules).forEach(function(V){Q.push(V.keyText,"{",V.style.cssText,"}")}),Q.push("}"),Q.join(" ")}(q):[CSSRule.IMPORT_RULE,CSSRule.FONT_FACE_RULE].includes(W)?function(L){return L.cssText.split("url(").map(function(Q){return Q[1]==="/"?"".concat(Q.slice(0,1)).concat(window.location.origin).concat(Q.slice(1)):Q}).join("url(")}(q):q.cssText,K.push(te)}});var ee=B.createElement("style");ee.textContent=K.join(`
`),O.appendChild(ee)}else if(A.href){var D=B.createElement("link");D.rel="stylesheet",D.href=A.href,O.appendChild(D)}}),void B.head.appendChild(O);var H,B,O},0),typeof T=="function"&&T(this.window),this.window.addEventListener("beforeunload",function(){return a.release()})}else typeof P=="function"?P(null):console.warn("A new window could not be opened. Maybe it was blocked.")}},{key:"componentWillUnmount",value:function(){if(this.state.mounted&&this.window){if(this.props.closeOnUnmount)this.window.close();else if(this.props.children){var g=this.container.cloneNode(!0);g.setAttribute("id","new-window-container-static"),this.window.document.body.appendChild(g)}}}},{key:"release",value:function(){if(!this.released){this.released=!0,clearInterval(this.windowCheckerInterval);var g=this.props.onUnload;typeof g=="function"&&g(null)}}}])&&St(d.prototype,m),v}();Re={url:"",name:"",title:"",features:{width:"600px",height:"640px"},onBlock:null,onOpen:null,onUnload:null,center:"parent",copyStyles:!0,closeOnUnmount:!0},(Le="defaultProps")in(Ne=Ee)?Object.defineProperty(Ne,Le,{value:Re,enumerable:!0,configurable:!0,writable:!0}):Ne[Le]=Re,Ee.propTypes={children:I.exports.node,url:I.exports.string,name:I.exports.string,title:I.exports.string,features:I.exports.object,onUnload:I.exports.func,onBlock:I.exports.func,onOpen:I.exports.func,center:I.exports.oneOf(["parent","screen"]),copyStyles:I.exports.bool,closeOnUnmount:I.exports.bool};const Nt=({data:f})=>{if(!f||!f.table)return null;const d=[];if(f.table.forEach(a=>{a.result&&Array.isArray(a.result.table)?a.result.table.forEach(w=>d.push(w)):a.panelNumber&&d.push(a)}),d.length===0)return null;const m=.13,u=a=>{let w=0,S=0;return a.forEach(N=>{w+=N.width_mm*N.item_qty,S+=N.item_qty}),S>1&&(w+=25*(S-1)),w},v=(a,w,S)=>{const N={};let J=0;a.gratings_data.forEach(E=>{const R=E.lCuttingNumber;N[R]||(N[R]=[]),N[R].push(E),E.rightCut>J&&(J=E.rightCut)});const x=Object.values(N);let P=0;x.forEach(E=>{const R=u(E);R>P&&(P=R)});const T=[];x.forEach((E,R)=>{const z=E[0],c=z.leftCut,H=z.rightCut,B=(50+c+5)*m,O=(50+H-5)*m;let A=0;E.forEach((Z,K)=>{const ee=Z.width_mm;for(let D=0;D<(Z.item_qty||1);D++){const q={position:"absolute",left:`${B}px`,top:`${(50+A)*m}px`,width:`${O-B}px`,height:`${ee*m}px`,backgroundColor:"#7F7FFF",border:"1px solid #000",boxSizing:"border-box",transform:"rotateX(25deg)",transformOrigin:"top left",transition:"transform 0.3s ease, background-color 0.3s ease",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",color:"#fff"},W=L=>{L.currentTarget.style.transform="rotateX(0deg) translateY(-5px)",L.currentTarget.style.backgroundColor="#FFA500"},te=L=>{L.currentTarget.style.transform="rotateX(25deg)",L.currentTarget.style.backgroundColor="#7F7FFF"};T.push(t.jsx("div",{style:q,onMouseEnter:W,onMouseLeave:te,children:Z.id},`p-${w}-c-${S}-s-${R}-g-${K}-i-${D}`)),A+=ee+25}})});const U={position:"relative",width:`${(J+100)*m}px`,height:`${(P+100)*m}px`,marginBottom:"20px",boxShadow:"0 4px 8px rgba(0, 0, 0, 0.5)",background:"repeating-linear-gradient(45deg, #e5e5e5, #e5e5e5 5px, #bfbfbf 5px, #bfbfbf 10px)",transform:"rotateX(25deg)",transformOrigin:"top left"},b={perspective:"1000px",marginBottom:"20px"};return t.jsxs("div",{style:b,children:[t.jsxs("h1",{style:{textAlign:"left"},children:["판번호: ",a.panelNumber," ",a.qty>1?`(${S+1}/${a.qty})`:""]}),t.jsx("div",{style:U,children:T})]},`panel-container-${w}-copy-${S}`)},g=[];return d.forEach((a,w)=>{for(let S=0;S<(a.qty||1);S++)g.push(v(a,w,S))}),t.jsx("div",{style:{width:"100%",overflowX:"auto",padding:"100px"},children:g})},Be={field:"index",headerName:"",width:30,sortable:!1,filterable:!1,disableColumnMenu:!0,cellClassName:"index-cell",renderCell:f=>f.api.getSortedRowIds().indexOf(f.id)+1},Lt=[Be,{field:"taskNumber",headerName:`태스크
번호`,flex:1},{field:"orderNumber",headerName:"수주번호",width:110},{field:"category",headerName:"구분",flex:1},{field:"orderDate",headerName:"수주일자",flex:1},{field:"deliveryDate",headerName:"납기일자",flex:1},{field:"customerCode",headerName:`수주
처명`,flex:1},{field:"totalQuantity",headerName:`총
수량`,flex:1},{field:"totalWeight",headerName:`총중량
(Kg)`,flex:1}],Rt=[Be,{field:"groupNumber",headerName:"그룹번호",width:160},{field:"percentage",headerName:`짝수
비율(%)`,flex:1},{field:"itemName",headerName:"품명",flex:1},{field:"specCode",headerName:"사양코드",width:140},{field:"compressionSetting",headerName:`압접본수
설정`,flex:1,renderCell:f=>f.value==="Optimized"?"2본 최적":f.value==="Basic"?"2본 기본":f.value},{field:"baseLength",headerName:`기본
로스`,flex:1},{field:"plusLAdjustment",headerName:`+L
공차`,width:50},{field:"minusLAdjustment",headerName:`-L
공차`,width:50},{field:"plusWAdjustment",headerName:`+W
공차`,width:50},{field:"minusWAdjustment",headerName:`-W
공차`,width:50}],Je=[Be,{field:"groupNumber",headerName:"그룹번호",width:160},{field:"totalQuantity",headerName:"총판수",flex:1},{field:"bbLossRate",headerName:"BB 손실율(%)",flex:1},{field:"cbLossRate",headerName:"CB 손실율(%)",flex:1},{field:"bbCode",headerName:"BB 코드",flex:1},{field:"bbUsage",headerName:"BB 사용량(Kg)",flex:1},{field:"bbLoss",headerName:"BB 손실량(Kg)",flex:1},{field:"cbCode",headerName:"CB 코드",flex:1},{field:"cbUsage",headerName:"CB 사용량(Kg)",flex:1},{field:"cbLoss",headerName:"CB 손실량(Kg)",flex:1}],xo=()=>{const f=h.useRef(null),d=h.useRef(null),m=h.useRef(null),u=h.useRef(null),v=h.useRef(null),[g,a]=h.useState(!1),[w,S]=h.useState(!1),[N,J]=h.useState([]),[x,P]=h.useState([]),[T,U]=h.useState([]),[b,E]=h.useState(null),[R,z]=h.useState(!1),[c,H]=h.useState(null),[B,O]=h.useState(!1),[A,Z]=h.useState("Optimized"),[K,ee]=h.useState(50),[D,q]=h.useState(3),[W,te]=h.useState("-3"),[L,Q]=h.useState(3),[V,Oe]=h.useState("-3"),[Ae,De]=h.useState(!1),[Ze,le]=h.useState(!1),[et,he]=h.useState([]),[oe,me]=h.useState(""),[_e,Pe]=h.useState(!1),[kt,fe]=h.useState({bbCode:"",cbCode:"",bWidth:0,cWidth:0,length:0,totalWeight:0,totalCB:0,totalPanel:0,totalQuantity:0,compressionSetting:"2본-최적",plusLAdjustment:3,minusLAdjustment:-3,plusWAdjustment:3,minusWAdjustment:-3,baseLength:50}),[tt,We]=h.useState(!1);_.interceptors.request.use(e=>{const o=localStorage.getItem("token");return o&&(e.headers.Authorization=`Bearer ${o}`),e},e=>Promise.reject(e)),_.interceptors.response.use(e=>e,e=>(e.response&&e.response.status===403&&(window.location.href="/auth/login"),Promise.reject(e))),h.useEffect(()=>{at()},[]),h.useEffect(()=>{if(N.length>0){const e=localStorage.getItem("startSelectedOrderId");if(e&&N.some(l=>l.id===parseInt(e))){const l=N.find(p=>p.id===parseInt(e));E(parseInt(e)),fe(p=>({...p,totalWeight:l.totalWeight,totalQuantity:l.totalQuantity})),be(parseInt(e))}}},[N]),h.useEffect(()=>{if(b){const e=JSON.parse(localStorage.getItem("completedMaterialInputs")||"[]");a(e.includes(b))}else a(!1)},[b]);const ot=async()=>{if(oe){le(!0);try{const o=(await _.get("/api/item/specific")).data.table,l=o.find(n=>n.systemCode===oe);if(!l){console.warn("해당 systemCode를 찾을 수 없습니다:",oe),he([]);return}const p=o.filter(n=>n.bbCode.split("-")[0]===l.bbCode.split("-")[0]&&n.cbCode===l.cbCode&&n.bWidth===l.bWidth&&n.cWidth===l.cWidth&&n.bladeThickness===l.bladeThickness);console.log("필터된 spec 리스트:",p),he(p)}catch(e){console.error("사양코드 목록 로드 실패:",e),he([])}}},nt=async()=>{if(!b||T.length===0){alert("처리할 절단 계획 결과가 없습니다.");return}S(!0);try{const e=T.reduce((i,r)=>{const s=(parseFloat(r.bbUsage)||0)+(parseFloat(r.bbLoss)||0),$=(parseFloat(r.cbUsage)||0)+(parseFloat(r.cbLoss)||0);return r.bbCode&&s>0&&(i[r.bbCode]=(i[r.bbCode]||0)+s),r.cbCode&&$>0&&(i[r.cbCode]=(i[r.cbCode]||0)+$),i},{}),o=Object.keys(e);if(o.length===0){alert("투입할 자재 사용량이 없습니다."),S(!1);return}const{data:l}=await _.get("/api/item/store"),p=l.table,n=new Set(p.map(i=>i.materialCode)),k=o.filter(i=>!n.has(i));if(k.length>0){alert(`재고에 없는 자재가 포함되어 있습니다: ${k.join(", ")}. 처리를 중단합니다.`),S(!1);return}const C=o.map(i=>{const r=p.find(X=>X.materialCode===i),s=e[i],$=(parseFloat(r.pcs)||0)+s,M={...r,pcs:$};return _.put(`/api/item/store/${r.id}`,M)});await Promise.all(C);const j=JSON.parse(localStorage.getItem("completedMaterialInputs")||"[]");j.includes(b)||(j.push(b),localStorage.setItem("completedMaterialInputs",JSON.stringify(j))),a(!0),alert("자재 투입이 완료 처리되었습니다.")}catch(e){console.error("자재 투입 처리 중 오류 발생:",e),alert("처리 중 오류가 발생했습니다. 다시 시도해 주세요.")}finally{S(!1)}},rt=async()=>{if(!(!b||!re||!oe)){Pe(!0);try{await _.put(`/api/plan/order-details/${b}`,{specCode:oe,group_id:re}),be(b),le(!1)}catch(e){console.error("사양코드 저장 실패:",e)}finally{Pe(!1)}}},st=async()=>{if(b){z(!0);try{const o=(await _.get(`/api/plan/order-details/${b}/groups`)).data.table,l=o.map(j=>j.groupNumber),p=new EventSource("/api/plan/events"),n=[];let k=!1;const C=setTimeout(()=>{k=!0,p.close(),console.warn("SSE response timeout. Using dummy data."),yt(()=>import("./CuttingPlan-6175cbd6.js"),[]).then(j=>{const i=j.default;n.push(i);const r=n.map(s=>{var M;const $=((M=s.result)==null?void 0:M.table.reduce((X,se)=>X+se.qty,0))||0;return{groupNumber:s.group_id,totalQuantity:$,bbLossRate:s.bbLossRate,cbLossRate:s.cbLossRate,bbCode:s.bbCode,bbUsage:s.bbUsage,cbUsage:s.cbUsage,bbLoss:s.bbLoss,cbCode:s.cbCode,cbLoss:s.cbLoss,result:s.result}});U(r),z(!1)}).catch(j=>console.error("Error loading dummy data:",j))},30*60*1e3);p.addEventListener("plan_complete",j=>{if(k)return;const i=JSON.parse(j.data);n.push(i);const r=n.map(s=>{var X;const $=((X=s.result)==null?void 0:X.table.reduce((se,ye)=>se+ye.qty,0))||0,M=s.totalCB||0;return{groupNumber:s.group_id,totalQuantity:$,totalCB:M,bbLossRate:s.bbLossRate,cbLossRate:s.cbLossRate,bbCode:s.bbCode,bbUsage:s.bbUsage,cbUsage:s.cbUsage,bbLoss:s.bbLoss,cbCode:s.cbCode,cbLoss:s.cbLoss,result:s.result,minusLAdjustment:s.minusLAdjustment,minusWAdjustment:s.minusWAdjustment,plusLAdjustment:s.plusLAdjustment,plusWAdjustment:s.plusWAdjustment}});U(r),n.length===o.length&&(clearTimeout(C),z(!1),p.close())});for(const j of l)await _.post("/api/plan/generate",{order_id:b,group_id:j,option:{compressionSetting:A,plusLAdjustment:D,minusLAdjustment:W,plusWAdjustment:L,minusWAdjustment:V}})}catch(e){console.error("Error generating plans:",e)}}},it=()=>{c&&We(!0)},at=async()=>{try{const o=(await _.get("/api/order/list")).data.table.map(l=>{var p,n;return{...l,orderDate:((p=l.orderDate)==null?void 0:p.split("T")[0])||"",deliveryDate:((n=l.deliveryDate)==null?void 0:n.split("T")[0])||""}});J(o)}catch(e){console.error("Error fetching top-left data:",e)}},be=async e=>{try{De(!0);const{data:o}=await _.get(`/api/plan/settings/${e}`),{data:l}=await _.get(`/api/plan/order-details/${e}/groups`),n=l.table.map((k,C)=>({...k,id:k.groupNumber||C,...o}));P(n)}catch(o){console.error("Error fetching top-right data:",o)}finally{De(!1)}},lt=async()=>{if(!b)return;const e=x.map(o=>o.groupNumber).join(",");U([]),z(!0);try{const l=(await _.get(`/api/plan/cutting-plan?order_id=${b}&group_id_list=${e}`)).data.table;console.log(l);const p=l.map(n=>{var C;const k=Array.isArray((C=n.result)==null?void 0:C.table)?n.result.table.reduce((j,i)=>j+i.qty,0):0;return{groupNumber:n.group_id,totalQuantity:k,totalCB:n.totalCB||0,bbLossRate:n.bbLossRate,cbLossRate:n.cbLossRate,bbCode:n.bbCode,bbUsage:n.bbUsage,cbUsage:n.cbUsage,bbLoss:n.bbLoss,cbCode:n.cbCode,cbLoss:n.cbLoss,result:n.result,minusLAdjustment:n.minusLAdjustment,minusWAdjustment:n.minusWAdjustment,plusLAdjustment:n.plusLAdjustment,plusWAdjustment:n.plusWAdjustment}});U(p)}catch(o){console.error("Error fetching past cutting plan:",o)}finally{z(!1)}},dt=async()=>{function e(o){const l=o.indexOf("-");let p=o;l!==-1&&(p=o.substring(0,l));const n=p.search(/\d/);if(n===-1)return o;const k=p.substring(0,n),C=p.substring(n);if(C.length<6)return o;const j=parseInt(C.substring(0,3),10);let i;if(C.length===7&&C.charAt(6)!=="0"){const r=parseInt(C.substring(3,6),10),s=C.substring(6,7);return i=s==="0"?r.toString():`${r}.${s}`,`${k}${j}*${i}`}else if(C.length>=9){const r=parseInt(C.substring(3,6),10),s=parseInt(C.substring(7,8),10);return`${k}${j}*${r}*${s}`}else{const r=parseInt(C.substring(3,6),10),s=C.length>6?C.substring(6,7):"0";return i=s==="0"?r.toString():`${r}.${s}`,`${k}${j}*${i}`}}if(c)try{const o=`
        width=1200,
        height=800,
        top=100,
        left=100,
        toolbar=no,
        menubar=no,
        scrollbars=no,
        resizable=no
      `,l=window.open("","PrintWindow",o);if(l){const p=[];c.result.table.forEach(i=>{i.gratings_data.forEach(r=>{p.push({panelNumber:i.panelNumber,qty:i.qty,lCuttingNumber:r.lCuttingNumber,lCuttingQty:r.item_qty||0,orderNumber:r.orderNumber,customerCode:r.customerCode,drawingNumber:r.drawingNumber,id:r.id,width_mm:r.width_mm,length_mm:r.length_mm,lep_mm:r.lep_mm,rep_mm:r.rep_mm,item_qty:r.item_qty||0,loss:i.loss,isLossRow:!1})}),p.push({panelNumber:i.panelNumber,isLossRow:!0,loss:i.loss})});const n=p.reduce((i,r,s)=>{const $=Math.floor(s/22);return i[$]||(i[$]=[]),i[$].push(r),i},[]),k=p.reduce((i,r)=>r.isLossRow?i:i+Number(r.lCuttingQty),0),C=p.reduce((i,r)=>r.isLossRow?i:i+Number(r.item_qty),0),j=`<!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>절단계획 상세 - 품목배치 리스트 (그룹번호: ${c.groupNumber})</title>
          <style>
            @page {
              size: A4 landscape;
              margin: 10mm 5mm 10mm 5mm;
            }
            @media print {
              .print-button {
                display: none;
              }
            }
            body {
              margin: 0;
              padding: 0;
              -webkit-print-color-adjust: exact;
            }
            .page {
              page-break-after: always;
            }
            .header {
              text-align: left;
              padding-left: 10px;
            }
            .header h2 {
              margin: 0;
              font-size: 20px;
            }
            .header-details {
              display: flex;
              justify-content: flex-start;
            }
            .header-details > h2{
              padding-right: 30px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            td {
              border: 1px solid black;
              padding-right: 3px;
              padding-top: 0px;
              padding-bottom: 0px;
              text-align: right;
              line-height: 25px;
              font-weight: bold;
              height: 25px;
            }
              td:nth-child(8),  /* 품목번호 */
              td:nth-child(10), /* 길이 */
              td:nth-child(12), /* REP */
              td:nth-child(13)  /* L 절단 수량 */ {
              border-right: 2px solid black;
            }
            th {
             border: 1px solid black;
              background-color: #B2B2B2;
              color: black;
              text-align: center;
              line-height: 20px;
              font-weight: bold;
              height: 20px;
            }
            tr {
              height: 25px;
            }
          </style>
        </head>
        <body>
          <button class="print-button" onclick="window.print()">출력</button>
          ${(()=>{let i="",r=null,s=!1;return n.length>0?n.map(($,M,X)=>{const se=X.slice(0,M).reduce((y,F)=>y+F.length,0),ye=$.map((y,F)=>{const we=se+F,ne=y.panelNumberForDisplay||y.panelNumber||"";!y.isLossRow&&ne!==""&&ne!==r&&(s=!s,i=s?"white":"yellow",r=ne);const Te=i?` style="background-color: ${i};"`:"",Me=' style="background-color: #B2B2B2;"';let Fe=ne,xe=y.qtyForDisplay||y.qty,Ce=y.orderNumber,Se=y.customerCode,Ue=y.lCuttingQty;if(we>0){let Y;F===0?Y=n[M-1][n[M-1].length-1]:Y=$[F-1];const ze=Y.panelNumberForDisplay||Y.panelNumber||"";ne===ze&&(Fe="");const ht=Y.qtyForDisplay||Y.qty;xe===ht&&(xe="");const mt=Y.orderNumber;Ce===mt&&(Ce="");const ft=Y.customerCode;Se===ft&&(Se=""),ne===ze&&y.lCuttingNumber===Y.lCuttingNumber&&(Ue="")}return y.isLossRow?`
                            <tr${Te}>
                              <td${Me}>${we+1}</td>
                              <td></td>
                              <td></td>
                              <td>Loss</td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td>${y.loss}</td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                            </tr>
                          `:`
                            <tr${Te}>
                              <td${Me}>${we+1}</td>
                              <td>${Fe}</td>
                              <td>${xe}</td>
                              <td>${y.lCuttingNumber}</td>
                              <td>${Ce}</td>
                              <td>${Se}</td>
                              <td>${y.drawingNumber}</td>
                              <td>${y.id}</td>
                              <td>${Math.round(y.width_mm)}</td>
                              <td>${Math.round(y.length_mm)}</td>
                              <td>${Math.round(y.lep_mm)}</td>
                              <td>${Math.round(y.rep_mm)}</td>
                              <td>${Ue}</td>
                              <td>${y.item_qty}</td>
                            </tr>
                          `}).join(""),pt=M===X.length-1?`
                        <tr style="color: black;">
                          <th></th>
                          <th>합계</th>
                          <th>총판수</th>
                          <th>절단수량</th>
                          <th>총 CB수량</th>
                          <th>총품목수량</th>
                          <th colspan="8"></th>
                        </tr>
                        <tr style="background-color: white; color: black;">
                          <td></td>
                          <td></td>
                          <td>${c.totalQuantity||"N/A"}</td>
                          <td>${c.result.table.reduce((y,F)=>y+F.qty*F.numberOfCuttings,0)}</td>
                          <td>${c.totalCB||0}</td>
                          <td>${c.result.table.reduce((y,F)=>y+F.qty*F.numberOfItems,0)}</td>
                          <td colspan="8"></td>
                        </tr>
                      `:"";return`
                        <div class="page">
                          <div class="header" style="">
                            <h2 style="font-size: 1.4em; text-decoration: underline; text-align: left;">절단계획 상세 - 품목배치 리스트 (그룹번호: ${c.groupNumber})</h2>
<div class="header-details" style="display: flex; justify-content: flex-start; align-items: center; gap: 30px;">
  <h2 style="font-size: 1.4em; margin: 0;">압접본수: ${c.compressionSetting||"2"}</h2>
  <h2 style="font-size: 1.4em; margin: 0;">총중량: ${c.result.totalWeight||"3"}</h2>
  <h2 style="font-size: 1.4em; margin: 0;">공차(+L: ${Number(c.plusLAdjustment||"3.00").toFixed(2)} -L: ${Number(c.minusLAdjustment||"-3.00").toFixed(2)} +W: ${Number(c.plusWAdjustment||"3.00").toFixed(2)} -W: ${Number(c.minusWAdjustment||"-3.00").toFixed(2)})</h2>
</div>

<div class="header-details" style="display: flex; justify-content: flex-start; align-items: center; gap: 45px; padding-bottom: 8px">
  <h2 style="font-size: 1.4em; margin: 0;">BB: ${c.bbCode?e(c.bbCode):"N/A"}</h2>
  <h2 style="font-size: 1.4em; margin: 0;">길이: ${c.bbCode.split("-")[1]||"N/A"}</h2>
  <h2 style="font-size: 1.4em; margin: 0;">BP: ${c.result.bWidth||"N/A"}</h2>
  <h2 style="font-size: 1.4em; margin: 0;">CB: ${c.cbCode?e(c.cbCode):"N/A"}</h2>
  <h2 style="font-size: 1.4em; margin: 0;">CP: ${c.result.cWidth||"N/A"}</h2>
  <h2 style="font-size: 1.4em; margin: 0;">EB: ${e(c.result.ebCode)||"SQ6*6"}</h2>
</div>
                          </div>
                          <table>
                            <thead>
                              <tr>
                                <th></th>
                                <th>판 번호</th>
                                <th>판수량</th>
                                <th>L 절단<br>번호</th>
                                <th>수주 번호</th>
                                <th>수주처명</th>
                                <th>도면번호/<br>품명</th>
                                <th>품목<br>번호</th>
                                <th>폭</th>
                                <th>길이</th>
                                <th>LEP</th>
                                <th>REP</th>
                                <th>L 절단<br>수량</th>
                                <th>품목<br>수량</th>
                              </tr>
                            </thead>
                            <tbody>
                              ${ye}
                              ${pt}
                            </tbody>
                          </table>
                        </div>
                      `}).join(""):"<p>데이터가 없습니다.</p>"})()}
        </body>
        </html>
        `;l.document.write(j),l.document.close()}}catch(o){console.error("Error fetching specific data:",o)}},ct=e=>{const o=e.row.id;localStorage.setItem("startSelectedOrderId",o);const l=e.row.totalWeight,p=e.row.totalQuantity;fe(n=>({...n,totalWeight:l,totalQuantity:p})),E(o),be(o)},ge=async()=>{if(b)try{await _.put(`/api/plan/settings/${b}`,{compressionSetting:A,plusLAdjustment:D,minusLAdjustment:W,plusWAdjustment:L,minusWAdjustment:V,baseLength:K}),fe(e=>({...e,compressionSetting:A,plusLAdjustment:D,minusLAdjustment:W,plusWAdjustment:L,minusWAdjustment:V,baseLength:K})),P(e=>e.map(o=>({...o,compressionSetting:A,plusLAdjustment:D,minusLAdjustment:W,plusWAdjustment:L,minusWAdjustment:V,baseLength:K}))),O(!1)}catch(e){console.error("설정 저장 오류:",e),alert("설정 저장에 실패했습니다.")}},[re,ut]=h.useState(null),[$t,Ie]=h.useState(null);return t.jsxs(xt,{title:"절단 계획 생성",children:[t.jsx("br",{}),t.jsxs(ie,{container:!0,spacing:2,children:[t.jsx(ie,{item:!0,xs:5,children:t.jsxs(je,{title:"절단계획 생성 대상",children:[t.jsx(de,{sx:{height:"calc(30vh - 32px)",width:"100%"},children:t.jsx(ve,{id:"top-left-grid",rows:N,columns:Lt,columnHeaderHeight:45,disableSelectionOnClick:!0,rowsPerPageOptions:[N.length],onRowClick:ct,selectionModel:b?[b]:[],rowSelectionModel:b?[b]:[],keepNonExistentRowsSelected:!1,rowHeight:25,sx:{"& .MuiDataGrid-cell":{border:"1px solid black",fontSize:"12px",paddingTop:"2px",paddingBottom:"2px"},"& .MuiDataGrid-columnHeader":{fontSize:"12px",backgroundColor:"#B2B2B2",border:"1px solid black"},"& .group0":{backgroundColor:"#ffffff"},"& .group1":{backgroundColor:"#f5f5f5"},"& .error-cell":{backgroundColor:"red",color:"white"},"& .MuiDataGrid-columnHeaderTitle":{whiteSpace:"pre-wrap",textAlign:"center",lineHeight:"1.2"},"& .MuiDataGrid-footerContainer":{display:""},"& .index-cell":{backgroundColor:"#B2B2B2"}}})}),t.jsxs(ce,{direction:"row",justifyContent:"flex-start",spacing:1,children:[t.jsx(G,{disabled:!b||R,onClick:st,children:R?t.jsx(ue,{size:24}):"계획 생성"}),t.jsx(G,{disabled:!b||x.length===0||Ae||R,onClick:lt,children:R?t.jsx(ue,{size:24}):"기계획 보기"}),t.jsx(G,{onClick:()=>O(!0),children:"설정 변경"})]})]})}),t.jsx(ie,{item:!0,xs:7,children:t.jsxs(je,{title:"그룹별 계획조건 개별지정",children:[t.jsx(de,{sx:{height:"calc(30vh - 32px)",width:"100%"},children:t.jsx(ve,{id:"top-right-grid",rows:x,columns:Rt,getRowId:e=>e.groupNumber,rowsPerPageOptions:[x.length],columnHeaderHeight:45,rowHeight:25,loading:Ae,onRowSelectionModelChange:e=>{const o=e[0];ut(o);const l=x.find(p=>p.groupNumber===o);l?(Ie(l),me(l.specCode)):(Ie(null),me(""))},rowSelectionModel:re?[re]:[],selectedOrderId:b,sx:{"& .MuiDataGrid-cell":{border:"1px solid black",fontSize:"12px",py:.5},"& .MuiDataGrid-columnHeader":{backgroundColor:"#B2B2B2",fontSize:"12px",border:"1px solid black"},"& .index-cell":{backgroundColor:"#B2B2B2"}}})}),t.jsx(ce,{direction:"row",justifyContent:"flex-start",spacing:1,children:t.jsx(G,{disabled:!re,onClick:ot,children:"사양코드 변경"})})]})})]}),t.jsx(ie,{container:!0,spacing:2,mt:3,children:t.jsx(ie,{item:!0,xs:12,children:t.jsxs(je,{title:"절단 계획 결과: 그룹별 사용자재",children:[t.jsx(de,{sx:{height:"calc(30vh)",width:"100%"},children:t.jsx(ve,{id:"bottom-grid",rows:T,getRowId:e=>e.groupNumber,onRowSelectionModelChange:e=>{const o=T.find(l=>l.groupNumber===e[0]);H(o)},columns:Je,columnHeaderHeight:30,rowsPerPageOptions:[Je.length],rowHeight:25,selectionModel:c?[c.groupNumber]:[],rowSelectionModel:c?[c.groupNumber]:[],keepNonExistentRowsSelected:!1,sx:{"& .MuiDataGrid-cell":{border:"1px solid black",fontSize:"12px",paddingTop:"2px",paddingBottom:"2px"},"& .MuiDataGrid-columnHeader":{fontSize:"12px",backgroundColor:"#B2B2B2",border:"1px solid black"},"& .group0":{backgroundColor:"#ffffff"},"& .group1":{backgroundColor:"#f5f5f5"},"& .error-cell":{backgroundColor:"red",color:"white"},"& .MuiDataGrid-columnHeaderTitle":{whiteSpace:"pre-wrap",textAlign:"center",lineHeight:"1.2"},"& .MuiDataGrid-footerContainer":{display:""},"& .index-cell":{backgroundColor:"#B2B2B2"}}})}),t.jsxs(ce,{direction:"row",justifyContent:"flex-end",spacing:2,children:[t.jsx(G,{disabled:!c,onClick:dt,children:"상세 품목배치(작업지시폼)"}),t.jsx(G,{disabled:!c,onClick:it,children:"상세보기"}),t.jsx(G,{variant:"contained",color:"primary",disabled:!T.length||g||w,onClick:nt,children:w?t.jsx(ue,{size:24}):g?"추가됨":"투입 완료"})]})]})})}),t.jsxs(He,{open:Ze,onClose:()=>le(!1),children:[t.jsx(Qe,{children:"사양코드 변경"}),t.jsxs(qe,{children:[t.jsx(wt,{label:"사양코드 선택",options:et,value:oe,onChange:e=>me(e.target.value)}),t.jsxs(de,{mt:2,display:"flex",justifyContent:"flex-end",children:[t.jsx(G,{onClick:()=>le(!1),children:"취소"}),t.jsx(G,{variant:"contained",onClick:rt,disabled:!oe||_e,startIcon:_e&&t.jsx(ue,{size:20}),children:"저장"})]})]})]}),t.jsxs(He,{open:B,onClose:()=>O(!1),children:[t.jsx(Qe,{children:"설정 변경"}),t.jsx(qe,{children:t.jsxs(ce,{spacing:2,sx:{mt:2},children:[t.jsxs(Ct,{label:"압접본 설정",value:A,onChange:e=>Z(e.target.value),fullWidth:!0,inputRef:f,onKeyDown:e=>{e.key==="Enter"&&(e.preventDefault(),d.current.focus())},children:[t.jsx(Ge,{value:"Optimized",children:"2본-최적"}),t.jsx(Ge,{value:"Basic",children:"2본-기본"})]}),t.jsx(ae,{label:"+L 공차",type:"number",value:D,onChange:e=>q(parseFloat(e.target.value)),inputRef:d,onKeyDown:e=>{e.key==="Enter"&&(e.preventDefault(),m.current.focus())}}),t.jsx(ae,{label:"-L 공차",type:"number",value:W,onChange:e=>{const o=e.target.value;(o==="-"||o===""||!isNaN(Number(o)))&&te(o)},onBlur:()=>{const e=parseFloat(W);isNaN(e)||te(e.toString())},inputRef:m,onKeyDown:e=>{e.key==="Enter"&&(e.preventDefault(),u.current.focus())}}),t.jsx(ae,{label:"+W 공차",type:"number",value:L,onChange:e=>Q(parseFloat(e.target.value)),inputRef:u,onKeyDown:e=>{e.key==="Enter"&&(e.preventDefault(),v.current.focus())}}),t.jsx(ae,{label:"-W 공차",type:"number",value:V,onChange:e=>{const o=e.target.value;(o==="-"||o===""||!isNaN(Number(o)))&&Oe(o)},onBlur:()=>{const e=parseFloat(V);isNaN(e)||Oe(e.toString())},inputRef:v,onKeyDown:e=>{e.key==="Enter"&&(e.preventDefault(),ge())}}),t.jsx(ae,{label:"기본 로스 (baseLength)",type:"number",value:K,onChange:e=>ee(parseFloat(e.target.value)),onKeyDown:e=>e.key==="Enter"&&ge()}),t.jsx(G,{variant:"contained",onClick:ge,children:"저장"})]})})]}),tt&&c&&t.jsx(Ee,{title:`도면 - 그룹번호: ${c.groupNumber}`,onUnload:()=>We(!1),copyStyles:!1,features:{width:1200,height:800,top:100,left:100,toolbar:"no",menubar:"no",scrollbars:"yes",resizable:"yes"},children:t.jsx(Nt,{data:c.result})})]})};export{xo as default};
