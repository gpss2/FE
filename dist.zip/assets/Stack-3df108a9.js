import{c as t}from"./createStack-ce6d82c8.js";const c=t(),o=c;export{o as S};
