import{r as o}from"./index-49fdfb35.js";const t=o.createContext(void 0),r=t;function e(){return o.useContext(r)}export{r as F,e as u};
