const e="/assets/emailSv-6b7ffb26.png";export{e};
