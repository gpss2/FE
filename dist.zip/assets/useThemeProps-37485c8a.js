import{b3 as m,b2 as o}from"./index-49fdfb35.js";import{u as s}from"./useThemeProps-bbbbdfa7.js";function a({props:e,name:r}){return s({props:e,name:r,defaultTheme:m,themeId:o})}export{a as u};
