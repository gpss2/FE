function u(...i){return i.reduce((n,t)=>t==null?n:function(...e){n.apply(this,e),t.apply(this,e)},()=>{})}export{u as c};
