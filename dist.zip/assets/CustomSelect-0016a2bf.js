import{j as t}from"./index-49fdfb35.js";import{S as o}from"./Select-a3b07079.js";import{s as m}from"./Box-6a0909bf.js";const a=m(s=>t.jsx(o,{...s}))();export{a as C};
