import"./index-49fdfb35.js";const n="/assets/maintenance-6cb605aa.svg";export{n as M};
