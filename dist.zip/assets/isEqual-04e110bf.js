import{z as r}from"./index-49fdfb35.js";import{v as o}from"./_baseIsEqual-52034fc0.js";var t=o;function u(a,s){return t(a,s)}var i=u;const E=r(i);export{i as a,E as i};
