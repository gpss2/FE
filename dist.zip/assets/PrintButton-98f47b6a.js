import{b0 as c,j as t}from"./index-49fdfb35.js";import{r as u}from"./createSvgIcon-f2e67151.js";import{I as p}from"./IconButton-3eb37206.js";var r={},m=c;Object.defineProperty(r,"__esModule",{value:!0});var i=r.default=void 0,b=m(u()),h=t;i=r.default=(0,b.default)((0,h.jsx)("path",{d:"M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3m-3 11H8v-5h8zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1m-1-9H6v4h12z"}),"Print");const w=({targetRef:l,title:o="Print"})=>{const s=()=>{const n=l.current;if(!n){console.error("인쇄 실패: 인쇄할 대상을 찾을 수 없습니다."),alert("인쇄할 대상을 찾을 수 없습니다.");return}const a=n.querySelector("table");if(!a){console.error("인쇄 실패: 대상 내부에서 테이블을 찾을 수 없습니다."),alert("인쇄할 테이블을 찾을 수 없습니다.");return}const d=a.outerHTML,e=window.open("","_blank");e.document.write(`
      <html>
        <head>
          <title>${o} 인쇄</title>
          <style>
            @media print {
              body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
              }
            }
            body { 
              font-family: 'Malgun Gothic', sans-serif; 
              margin: 20px;
            }
            table { 
              width: 100%; 
              border-collapse: collapse; 
              table-layout: fixed; 
            }
            th, td { 
              border: 1px solid black; 
              padding: 8px; 
              text-align: center; 
              overflow-wrap: break-word;
            }
            th { 
              background-color: #B2B2B2 !important; 
              font-size: 14px; 
              font-weight: bold;
              white-space: pre-wrap; 
              line-height: 1.2; 
            }
            td { 
              font-size: 12px; 
            }
          </style>
        </head>
        <body>
          <h2>${o}</h2>
          ${d}
        </body>
      </html>
    `),e.document.close(),e.focus(),setTimeout(()=>{e.print(),e.close()},250)};return t.jsx(p,{color:"secondary",sx:{border:"1px solid",borderColor:"secondary.main",borderRadius:1},onClick:s,children:t.jsx(i,{})})};export{w as P};
