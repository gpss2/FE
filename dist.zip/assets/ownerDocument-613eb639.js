function o(n){return n&&n.ownerDocument||document}export{o};
