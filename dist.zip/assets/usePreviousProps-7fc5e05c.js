import{r as e}from"./index-49fdfb35.js";const o=s=>{const r=e.useRef({});return e.useEffect(()=>{r.current=s}),r.current},u=o;export{u};
