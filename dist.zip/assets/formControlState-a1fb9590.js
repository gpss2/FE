function d({props:e,states:u,muiFormControl:r}){return u.reduce((n,f)=>(n[f]=e[f],r&&typeof e[f]>"u"&&(n[f]=r[f]),n),{})}export{d as f};
