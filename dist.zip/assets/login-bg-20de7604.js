import"./index-49fdfb35.js";const a="/assets/login-bg-87ac6a5f.svg";export{a as i};
